TestRail API Binding for .NET
-----------------------------

You can learn more about TestRail's API and how to use the .NET binding here:

http://docs.gurock.com/testrail-api2/start

http://docs.gurock.com/testrail-api2/bindings-dotnet

The binding uses the Json.NET library for encoding/decoding JSON data,
copyright James Newton-King, licensed under the MIT license and available
here:

http://james.newtonking.com/json


For questions, suggestions, or other requests, please reach out to us through our support channels:

https://www.gurock.com/testrail/support
